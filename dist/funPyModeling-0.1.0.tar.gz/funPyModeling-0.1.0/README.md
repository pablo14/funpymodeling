# funPyModeling
A package to help data scientist in Exploratory Data Analysis and Data Preparation for ML models
